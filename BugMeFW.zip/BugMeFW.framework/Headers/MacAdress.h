//
//  MacAdress.h
//  CrashManager
//
//  Created by Charanjit Singh on 17/10/16.
//  Copyright © 2016 Charanjit Singh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MacAdress : NSObject

+ (NSString *)macAdress;


@end
