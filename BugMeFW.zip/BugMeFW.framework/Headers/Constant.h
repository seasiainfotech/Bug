//
//  Constant.h
//  BugMe
//
//  Created by Charanjit Singh on 17/10/16.
//  Copyright © 2016 Charanjit Singh. All rights reserved.
//

#ifndef Constant_h
#define Constant_h
#define kDeviceName @"deviceName"
#define kDeviceInfo @"deviceInfo"
#define kCrashReport @"crashReport"
#define kLogs @"logs"
#define kUserLogs @"userLogs"
#define kCauseBy @"CauseBy"
# define KAppdelegate  ((AppDelegate*) [[UIApplication sharedApplication] delegate])
//demo.bugme
#endif /* Constant_h */
